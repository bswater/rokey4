#!/usr/bin/env python3
#
# Copyright 2018 ROBOTIS CO., LTD.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Author: Leon Jung, Gilbert, Ashe Kim, Jun

from enum import Enum
import os

import cv2
from cv_bridge import CvBridge
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from sensor_msgs.msg import Image
from std_msgs.msg import UInt8, String


class DetectSign(Node):

    def __init__(self):
        super().__init__('detect_sign')

        self.sub_image_type = 'raw'  # you can choose image type 'compressed', 'raw'
        self.pub_image_type = 'compressed'  # you can choose image type 'compressed', 'raw'

        if self.sub_image_type == 'compressed':
            self.sub_image_original = self.create_subscription(
                CompressedImage,
                '/detect/image_input/compressed',
                self.cbFindTrafficSign,
                10
            )
        elif self.sub_image_type == 'raw':
            self.sub_image_original = self.create_subscription(
                Image,
                '/detect/image_input',
                self.cbFindTrafficSign,
                10
            )

        self.pub_traffic_sign = self.create_publisher(String, '/detect/sign', 1)
        if self.pub_image_type == 'compressed':
            self.pub_image_traffic_sign = self.create_publisher(
                CompressedImage,
                '/detect/image_output/compressed', 10
            )
        elif self.pub_image_type == 'raw':
            self.pub_image_traffic_sign = self.create_publisher(
                Image, '/detect/image_output', 10
            )

        self.cvBridge = CvBridge()
        self.TrafficSign = Enum('TrafficSign', 'tunnel')
        self.counter = 1

        self.fnPreproc()

        self.get_logger().info('DetectSign Node Initialized')

    def fnPreproc(self):
        # Initiate SIFT detector
        self.sift = cv2.SIFT_create()

        dir_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        dir_path = os.path.join(dir_path, 'image')

        self.img_10km = cv2.imread(dir_path + '/vel_10.png', 0)  # trainImage3
        self.img_50km = cv2.imread(dir_path + '/vel_50.png', 0)  # trainImage3
        self.kp_10km, self.des_10km = self.sift.detectAndCompute(self.img_10km, None)

        self.kp_50km, self.des_50km = self.sift.detectAndCompute(self.img_50km, None)

        FLANN_INDEX_KDTREE = 0
        index_params = {
            'algorithm': FLANN_INDEX_KDTREE,
            'trees': 5
        }

        search_params = {
            'checks': 50
        }

        self.flann = cv2.FlannBasedMatcher(index_params, search_params)

    def fnCalcMSE(self, arr1, arr2):
        squared_diff = (arr1 - arr2) ** 2
        total_sum = np.sum(squared_diff)
        num_all = arr1.shape[0] * arr1.shape[1]  # cv_image_input and 2 should have same shape
        err = total_sum / num_all
        return err

    def cbFindTrafficSign(self, image_msg):
        # drop the frame to 1/5 (6fps) because of the processing speed.
        # This is up to your computer's operating power.
        if self.counter % 3 != 0:
            self.counter += 1
            return
        else:
            self.counter = 1

        if self.sub_image_type == 'compressed':
            # converting compressed image to opencv image
            np_arr = np.frombuffer(image_msg.data, np.uint8)
            cv_image_input = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        elif self.sub_image_type == 'raw':
            cv_image_input = self.cvBridge.imgmsg_to_cv2(image_msg, 'bgr8')


        # --- SIFT는 그레이스케일 권장 ---
        gray = cv2.cvtColor(cv_image_input, cv2.COLOR_BGR2GRAY)

        MIN_MATCH_COUNT = 5
        MIN_MSE_DECISION = 50000

        # keypoints & descriptors
        kp1, des1 = self.sift.detectAndCompute(gray, None)
        if des1 is None or len(kp1) == 0:
            # 특징점이 없으면 이번 프레임 패스
            return
        # find the keypoints and descriptors with SIFT

        matches_10km = self.flann.knnMatch(des1, self.des_10km, k=2)
        matches_50km = self.flann.knnMatch(des1, self.des_50km, k=2)

        image_out_num = 1

        # 10km 매칭
        good_10km = []
        for m, n in matches_10km:
            if m.distance < 0.7 * n.distance:
                good_10km.append(m)

        if len(good_10km) > MIN_MATCH_COUNT:
            src_pts = np.float32([kp1[m.queryIdx].pt for m in good_10km]).reshape(-1,1,2)
            dst_pts = np.float32([self.kp_10km[m.trainIdx].pt for m in good_10km]).reshape(-1,1,2)
            M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
            matchesMask_10km = None if mask is None else mask.ravel().tolist()

            mse = self.fnCalcMSE(src_pts, dst_pts)
            if mse < MIN_MSE_DECISION:
                msg_sign = String()
                msg_sign.data = "km_10"
                self.pub_traffic_sign.publish(msg_sign)
                self.get_logger().info('10km')
                image_out_num = 4
        else:
            matchesMask_10km = None

        # 50km 매칭
        good_50km = []
        for m, n in matches_50km:
            if m.distance < 0.7 * n.distance:
                good_50km.append(m)

        if len(good_50km) > MIN_MATCH_COUNT:
            src_pts = np.float32([kp1[m.queryIdx].pt for m in good_50km]).reshape(-1,1,2)
            dst_pts = np.float32([self.kp_50km[m.trainIdx].pt for m in good_50km]).reshape(-1,1,2)
            M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
            matchesMask_50km = None if mask is None else mask.ravel().tolist()

            mse = self.fnCalcMSE(src_pts, dst_pts)
            if mse < MIN_MSE_DECISION:
                msg_sign = String()
                msg_sign.data = "km_50"
                self.pub_traffic_sign.publish(msg_sign)
                self.get_logger().info('50km')
                image_out_num = 5
        else:
            matchesMask_50km = None

        # --- 출력(그림 그리기 부분은 기존 그대로) ---
        if image_out_num == 1:
            if self.pub_image_type == 'compressed':
                self.pub_image_traffic_sign.publish(
                    self.cvBridge.cv2_to_compressed_imgmsg(cv_image_input, 'jpg'))
            else:
                self.pub_image_traffic_sign.publish(
                    self.cvBridge.cv2_to_imgmsg(cv_image_input, 'bgr8'))
        elif image_out_num == 4:
            draw_params_10km = dict(matchColor=(255,0,0), singlePointColor=None,
                                    matchesMask=matchesMask_10km, flags=2)
            final_10km = cv2.drawMatches(cv_image_input, kp1, self.img_10km, self.kp_10km,
                                        good_10km, None, **draw_params_10km)
            if self.pub_image_type == 'compressed':
                self.pub_image_traffic_sign.publish(
                    self.cvBridge.cv2_to_compressed_imgmsg(final_10km, 'jpg'))
            else:
                self.pub_image_traffic_sign.publish(
                    self.cvBridge.cv2_to_imgmsg(final_10km, 'bgr8'))
        elif image_out_num == 5:
            draw_params_50km = dict(matchColor=(255,0,0), singlePointColor=None,
                                    matchesMask=matchesMask_50km, flags=2)
            final_50km = cv2.drawMatches(cv_image_input, kp1, self.img_50km, self.kp_50km,
                                        good_50km, None, **draw_params_50km)
            if self.pub_image_type == 'compressed':
                self.pub_image_traffic_sign.publish(
                    self.cvBridge.cv2_to_compressed_imgmsg(final_50km, 'jpg'))
            else:
                self.pub_image_traffic_sign.publish(
                    self.cvBridge.cv2_to_imgmsg(final_50km, 'bgr8'))


def main(args=None):
    rclpy.init(args=args)
    node = DetectSign()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
