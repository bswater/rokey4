^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package dynamixel_sdk_examples
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.8.4 (2025-05-28)
------------------
* Deprecate ament_include_dependency usage in CMakeLists.txt
* Contributors: Wonho Yun

3.8.3 (2025-03-31)
------------------
* None

3.8.2 (2025-03-13)
------------------
* Added ROS 2 Python example
* Contributors: Wonho Yun

3.8.1 (2025-02-12)
------------------
* None

3.7.60 (2022-06-03)
-------------------
* ROS 2 Humble Hawksbill supported
* Contributors: Will Son

3.7.40 (2021-04-14)
-------------------
* Add ROS 2 basic example
* Contributors: Will Son
